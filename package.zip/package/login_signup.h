#ifndef LOGIN_SIGNUP_H
#define LOGIN_SIGNUP_H

#include <stdio.h>
#include <string.h>
#include <stdbool.h>
#include <stdlib.h>

//-----[PROTOTYPE]-----//
void loginOrSignup();
void readDataFromFile();
void saveInfor();
void printInforInFile();
void pressLogin();
void pressSignUp();
bool checkTaiKhoanMatKhau(char *taiKhoanInput, char *matKhauInput);
bool checkTaiKhoan(char *taiKhoanInput);
bool check2Chuoi(char *s1, char *s2);
bool checkFormatInput(char *str);
//

//
typedef struct
{
    char taiKhoan[20];
    char matKhau[20];
    char name[30];
    int tien;
} ACCOUNT;
//

static ACCOUNT listAcc[200]; // luu tru cac tai khoan
static int count = 0;

// MAIN
void loginOrSignup()
{
    system("cls");
    readDataFromFile();
    // printInforInFile();

    printf("[Q]. dang nhap   [W]. dang ki\n");
    char pick;

    while (true)
    {
        pick = getchar();

        if (pick >= 97 && pick <= 122)
            pick -= 32;
        if (pick == 'Q' || pick == 'W')
            break;
    }

    if (pick == 'Q')
    {
        pressLogin();
    }
    else if (pick == 'W')
    {
        pressSignUp();
    }
}
//

// doc data tu file roi luu vao mang account
// "data.txt"
void readDataFromFile()
{
    char read[200][80];
    FILE *fr = fopen("data.txt", "r");

    int i = 0;
    while (true)
    {
        fgets(read[i], 80, fr);
        if (strlen(read[i]) == 0) // doc het thi dung
            break;
        sscanf(read[i], "%s %s %s %d", listAcc[i].taiKhoan, listAcc[i].matKhau, listAcc[i].name, &(listAcc[i].tien));
        i++;
    }
    count = i;
    fclose(fr);
}
//

//[UNIT TEST] in thong tin doc duoc tu trong file
void printInforInFile()
{
    for (int i = 0; i < count; i++)
    {
        printf("%s_and_%s_and_%s_and_%d\n", listAcc[i].taiKhoan, listAcc[i].matKhau, listAcc[i].name, listAcc[i].tien);
    }
}
//

// neu an login
void pressLogin()
{
    getchar();
    char taiKhoanInput[20];
    char matKhauInput[20];

    while (true)
    {
        printf("\nnhap tai khoan roi mat khau: ");
        gets(taiKhoanInput);
        gets(matKhauInput);
        if (checkTaiKhoanMatKhau(taiKhoanInput, matKhauInput) && checkFormatInput(taiKhoanInput) && checkFormatInput(matKhauInput)) // neu ton tai va dung dinh dang
            break;
    }

    // neu dung thi ket thuc, chuyen qua menu
}
//

// neu an signup
void pressSignUp()
{
    getchar();
    char taiKhoanInput[20];
    char matKhauInput[20];
    char nameInput[30];

    while (true)
    {
        printf("\nnhap tai khoan roi mat khau roi username: ");
        gets(taiKhoanInput);
        gets(matKhauInput);
        gets(nameInput);
        if (checkTaiKhoan(taiKhoanInput) && checkFormatInput(nameInput) && checkFormatInput(taiKhoanInput) && checkFormatInput(matKhauInput)) // neu ton tai va dung dinh dang
            break;
    }

    // them thong tin user vao cuoi danh sach
    strcpy(listAcc[count].taiKhoan, taiKhoanInput);
    strcpy(listAcc[count].matKhau, matKhauInput);
    strcpy(listAcc[count].name, nameInput);
    listAcc[count].tien = 1000;
    count++;

    saveInfor();

    // neu dung thi ket thuc, chuyen qua menu
}
//

// luu toan bo thong tin vao file "data.txt"
void saveInfor()
{
    FILE *fw = fopen("data.txt", "w");

    for (int i = 0; i < count; i++)
    {
        fprintf(fw, "%s %s %s %d\n", listAcc[i].taiKhoan, listAcc[i].matKhau, listAcc[i].name, listAcc[i].tien);
    }

    fclose(fw);
}
//

// kiem tra tai khoan, mat khau co dung trong data khong [DUNG CHO LOGIN]
//  co -> T
//  khong -> F
bool checkTaiKhoanMatKhau(char *taiKhoanInput, char *matKhauInput)
{
    for (int i = 0; i < count; i++)
    {
        if (check2Chuoi(listAcc[i].taiKhoan, taiKhoanInput) && check2Chuoi(listAcc[i].matKhau, matKhauInput))
            return true;
    }
    return false;
}
//

// kiem tra tai khoan da ton tai trong data khong [DUNG CHO SIGN UP]
//  co -> F
//  khong -> T
bool checkTaiKhoan(char *taiKhoanInput)
{
    for (int i = 0; i < count; i++)
    {
        if (check2Chuoi(listAcc[i].taiKhoan, taiKhoanInput))
            return false;
    }
    return true;
}
//

// check 2 chuoi giong nhau
// giong -> T
// khac -> F
bool check2Chuoi(char *s1, char *s2)
{
    int len1 = strlen(s1);
    int len2 = strlen(s2);

    // neu do dai khac nhau -> khac
    if (len1 != len2)
        return false;
    // neu do dai giong nhau, thi so tung ki tu
    else
    {
        for (int i = 0; i < len1; i++)
        {
            if (s1[i] != s2[i])
                return false;
        }
        return true;
    }
}
//

// kiem tra dinh dang 1 chuoi, xem co thoa man khong
// khong co spcae, ki tu dac biet, do dai >=6 va <=18
// thoa man -> T
// sai dinh dang -> F
bool checkFormatInput(char *str)
{
    int len = strlen(str);
    if (len < 6 || len > 18) // check do dai
        return false;
    // check space, ki tu dac biet
    for (int i = 0; i < len; i++)
    {
        if (str[i] < 48 || (str[i] > 57 && str[i] < 65) || (str[i] > 90 && str[i] < 97) || str[i] > 122)
            return false;
    }
    return true;
}
//

#endif