#include <stdio.h>
#include <stdlib.h>
#include "playingGame.h"
#include "UI.h"
#include "login_signup.h"

int main()
{
    loginOrSignup();
    printf("\n\tpass. . .\n");
    system("pause");
}
