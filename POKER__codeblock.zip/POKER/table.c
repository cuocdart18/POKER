#include "login_signup.h"
#include "delayTime.h"
#include "playingGame.h"
#include "UI.h"

int main()
{
    UI_logIn();
    loginOrSignup();

    printLoading();

    gotoxy(0, 50);
    system("pause");
}
