
#ifndef NHAPTIEN_H
#define NHAPTIEN_H

#include <stdio.h>
#include <windows.h>
#include <conio.h>
#include <string.h>
#include <time.h>
#include <stdbool.h>
#include "UI.h"

//tra ve so tien ban dau cua nguoi choi
int nhapTien()
{
    system("cls");
    int soChipBanDau;
    printVienNgoai();

    printBangNhapTien();

    gotoxy(56, 22);

    printf("Nhap so chip ban co: ");
    scanf("%d", &soChipBanDau);
    return soChipBanDau;
}

// in bang nhap tien truoc khi vao game
void printBangNhapTien()
{
    int x = 55, y = 20;
    gotoxy(x, y);

    // in noti
    SetTeColor(20);
    printHinhChuNhat(5, 56, x, y);
    SetTeColor(7);
}
//

#endif
