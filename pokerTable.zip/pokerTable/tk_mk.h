#ifndef TKMK_H_
#define TKMK_H_


#include <stdio.h>
#include <stdbool.h>
#include <stdlib.h>
#include <time.h>
#include <string.h>
typedef struct
{

    char taikhoan[30];
    char matKhau[30];
    char username[30];
    int SoDu[30];

} TaiKhoan;

void CheckAcc(char a[], char b[])
{
    if (strlen(a) == 0 || strlen(b) == 0)
        printf("Tai khoan hoac mat khau khong dung\n");
    else
    {
        FILE *f = fopen("tk.txt", "r"); // tách tk, mk , username, số tiền từ file

        char LayTuFile[1000][100];
        char tk[1000][100], mk[1000][100], ten[1000][100];
        int tien[10];
        int sotk = 0;

        for (int i = 0; i < 1000; i++)
        {
            fgets(LayTuFile[i], 100, f);
            if (strlen(LayTuFile[i]) == 0)
                break;
            sscanf(LayTuFile[i], "%s %s %s  %d", tk[i], mk[i], ten[i], &tien[i]);
            sotk++;
        }

        for (int i = 0; i < sotk; i++) //Đối chiếu tk, mk nhập vào lần lượt với các tk, mk được tách từ file
        {
            int checkn = 0;
            int lenOfTk = strlen(tk[i]);
            for (int t = 0; t < lenOfTk; t++)
            {
                if (tk[i][t] != a[t])
                    break;
                checkn++;
            }
            int lenOfMk = strlen(mk[i]);
            for (int t = 0; t < lenOfMk; t++)
            {
                if (mk[i][t] != b[t])
                    break;
                checkn++;
            }
            if (checkn == strlen(tk[i]) + strlen(mk[i]))
            {
                printf("Ten cua ban la: %s\nSo du hien tai: %d\n", ten[i], tien[i]);
                return ten[i], tien[i];
                break;
            }
        }

        fclose(f);
    }
}

typedef struct node
{

    TaiKhoan data;
    struct node *next;

} node;

node *first = NULL;

/*
    Xây d?ng node
    - C?p phát node
    - Gán/nh?p giá tr? node
    - Con tr? next
*/

node *capPhatNode()
{

    node *pNode = (node *)malloc(sizeof(node));
    return pNode;
}

TaiKhoan LogIn()
{

    TaiKhoan tk;

    printf("Tai Khoan :");
    fflush(stdin);
    gets(tk.taikhoan);

    printf("Mat Khau :");
    fflush(stdin);
    gets(tk.matKhau);

    char ten[1000][100];
    int tien[10];

    CheckAcc(tk.taikhoan, tk.matKhau);
}

node *taoVaNhapNode()
{

    node *pNode = capPhatNode();
    pNode->data = LogIn();
    pNode->next = NULL;

    return pNode;
}

void themNodeDauTien(node *pNode)
{

    first = pNode;
    pNode->next = NULL;
}

void themNodeViTriDau(node *pNode)
{

    if (first == NULL)
        themNodeDauTien(pNode);
    else
    {
        pNode->next = first;
        first = pNode;
    }
}

//int main()
//{
//    LogIn();
//}

#endif // TKMK_H_
